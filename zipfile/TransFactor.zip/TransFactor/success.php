<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/success.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="js/background.js" async></script>
    <script src="js/success.js" async></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <title>Document</title>
</head>

<header class="menu">
<?php
include "log.php";
?>
<a class="a1">Aide</a>
<a class="a2">A Propos</a>

</header>

<body>
<?php

 $file = $_FILES['nom'];
 $image = addslashes($_FILES['nom']['tmp_name']);
 $size = $_FILES['nom']['size'];
 $error = $_FILES['nom']['error'];
 $type = $_FILES['nom']['type'];
 $name = uniqid();

     $dossier = 'upload/';
     $fichier = basename($name);
     if(move_uploaded_file($image , $dossier .'/'. $name)) //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
     {
          echo '';
     }
     else //Sinon (la fonction renvoie FALSE).
     {
          echo '';
     }

$extensions = array('.png', '.gif', '.jpg', '.jpeg');
$extension = strrchr($name, '.');

if(!in_array($extension, $extensions)) //Si l'extension n'est pas dans le tableau
{
  $erreur = 'Vous devez uploader un fichier de type png, gif, jpg, jpeg, txt ou doc...';
}
$url= "http://localhost/Dev/TransFactor/download.php?dossier=$dossier&amp;fichier=$name";
$msg = "First line of text\nSecond line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
$myMail = $_POST['monEmail'];
$sendMail = $_POST['sonEmail'];
$txt = $_POST['message'];
//include "mail.php";
 ?>
    <div class="success"> 
    <img class="img1" src="img/check-circle.svg" class="icon">
    
    <h2>Votre fichier a bien été envoyé !</h2>

    <h2> Voici le lien de votre téléchargement ! </h2>
    
        <div class="lien">
            <textarea id="to-copy" spellcheck="false"><?php echo $url; ?></textarea><br/>

            <!-- Boutton pour le presse papier -->

            <button id="copy" type="button"><img class="img2" src="https://png.icons8.com/metro/50/000000/copy.png"></button>
        </div>

    </div>
</body>
</html>