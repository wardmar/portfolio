function Bretagne(){
    $('#map').load('css/dep/bretagne.svg')
}

function paysLoire(){
    $('#map').load('css/dep/payloire.svg')
}

function IleDeFrance(){
    $('#map').load('css/dep/iledef.svg')
}

function Provence(){
    $('#map').load('css/dep/provence.svg')
}

function Corse(){
    $('#map').load('css/dep/corse.svg')
}

function Normandie(){
    $('#map').load('css/dep/normandie.svg')
}

function HautsDeFrance(){
    $('#map').load('css/dep/hautdef.svg')
}

function GrandEst(){
    $('#map').load('css/dep/grandest.svg')
}

function Occitanie(){
    $('#map').load('css/dep/occitanie.svg')
}

function Auvergne(){
    $('#map').load('css/dep/auvergne.svg')
}

function ValDeLoire(){
    $('#map').load('css/dep/centre.svg')
}

function nouvelleAquitaine(){
    $('#map').load('css/dep/nouvelleaqui.svg')
}

function Bourgogne(){
    $('#map').load('css/dep/bourgogne.svg')
}
