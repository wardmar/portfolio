function valider() {
    // si la valeur du champ prenom est non vide
    if((document.getElementsByName('monEmail').value != "")&&(document.getElementsByName('sonEmail').value != "")&&(document.getElementsByName('message').value != "")&&(document.getElementsByName('nom').value != "")) {
      // alors on envoie le formulaire
      document.formSaisie.submit();
    }
    else {
      // sinon on affiche un message
      alert("vous n'avez pas saisi toute les données");
    }
  }
  document.getElementsByName