<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/download.css" rel="stylesheet">
    <script src="js/background.js" async></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <title>Document</title>
</head>

<header class="menu">

<a class="a1">Aide</a>
<a class="a2">A Propos</a>

</header>

<body>

    <div class="download"> 

        <h1> Pour télécharger votre fichier , cliquez ! </h1>

        <!--  On donne une variable pour le href et download -->

        <a class="a1 tele" href="<?php echo $_GET['dossier'] ?><?php echo $_GET['fichier'] ?>" download="coucou">TELECHARGER</a>
    </div>

</body>
</html>