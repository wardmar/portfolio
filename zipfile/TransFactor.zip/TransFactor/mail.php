<?php
$to = $sendMail;
$subject = 'fichier envoyer par' + $myMail;
$txt = '<html>
<head>

</head>
<body>

<table cellspacing="0" cellpadding="0" style="width:525pt">
<tbody>
</br>
</br>
<h1 align="center" style= "color: #8BC34A">TRANSFACTOR</h1>
<tr>
</br>
</br>
</br> 


<p align= "center" >
votre fichier est en cours de telechargement </br>veuillez cliquer sur le lien ci dessous pour recuperer votre fichier</br>
</p></br>
</br>
<p align="center" >
<a style= "color: #5A9216" href="'+$url;'" ></a>

</p>

</tr>
</tbody>
</table>
</body>
</html>';
 
$headers  = 'From: ' + $myMail."\r\n";
$headers .= 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

mail($to,$subject,$txt,$headers);
?>
