<?php
$servername = 'localhost';
$database = 'Monu';
$username = 'Dev';
$password = 'luwasx18500';

?>